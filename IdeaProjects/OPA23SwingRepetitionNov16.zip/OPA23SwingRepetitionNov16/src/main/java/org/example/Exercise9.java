package org.example;

import javax.swing.*;

public class Exercise9 {
    private JPanel exercise9Panel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JButton sendEmailButton;
    private JTextField textField6;
    private JTextArea march2016January2016TextArea;
    private JTextArea moviesMusicSportsTechTextArea;
    private JTextArea siteAdminLogOutTextArea;

    private Form form;

    /*Återskapa denna sida så gott som du kan grafiskt. Kom ihåg att använda JPanels för att
      avdela olika områden i din form.*/
    public Exercise9() {
        form = new Form(exercise9Panel, "Exercise 9", JFrame.DISPOSE_ON_CLOSE);
    }
}
