package org.example;

import javax.swing.*;

public class Exercise3 {
    /*Så gott som du kan, använd Swing GUI Designer för att skapa liknelsen till en hund i en form
      användandes bara JPanels och Buttons. Lite sprite-art, så till att säga.*/

    private Form form;
    private JPanel exercise3Panel;

    public Exercise3() {
        form = new Form(exercise3Panel, "Exercise 3", JFrame.DISPOSE_ON_CLOSE);
    }
}
